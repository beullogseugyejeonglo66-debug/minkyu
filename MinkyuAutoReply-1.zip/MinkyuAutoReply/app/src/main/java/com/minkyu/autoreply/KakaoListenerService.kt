package com.minkyu.autoreply

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * 카카오톡 알림을 읽고, 알림의 '답장(RemoteInput)' 액션으로 답장한다.
 * 카카오톡 앱을 열 필요도, 접근성 서비스도 필요 없다.
 */
class KakaoListenerService : NotificationListenerService() {

    companion object {
        private const val KAKAO = "com.kakao.talk"
        private const val TAG = "MinkyuAutoReply"
        private var engine: ConversationEngine? = null
    }

    private val recent = LinkedHashSet<String>()
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        if (engine == null) {
            val app = applicationContext
            val prefs = Prefs(app)
            engine = ConversationEngine(
                keywords = { prefs.keywords() },
                presence = { ForegroundAppDetector(app).current() },
                notifyUser = { sender, _ -> Notifier.post(app, Notifier.callAlert(sender)) },
            )
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != KAKAO) return
        if (!Prefs(this).enabled) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val sub = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()
        var text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()

        @Suppress("DEPRECATION")
        val last = ex.getParcelableArray(Notification.EXTRA_MESSAGES)?.lastOrNull() as? Bundle
        val msgText = last?.getCharSequence("text")?.toString()
        if (!msgText.isNullOrBlank()) text = msgText.trim()
        val msgSender = last?.getCharSequence("sender")?.toString()?.trim()

        val room: String
        val sender: String
        if (!msgSender.isNullOrEmpty()) { sender = msgSender; room = if (sub.isNotEmpty()) sub else title }
        else if (sub.isNotEmpty()) { sender = title; room = sub }   // 단체방: 제목=발신자, 부제목=방 이름
        else { sender = title; room = title }                       // 1:1
        if (text.isEmpty() || sender.isEmpty()) return

        val dedupe = "${sbn.key}|${n.`when`}|$text"
        synchronized(recent) {
            if (!recent.add(dedupe)) return
            if (recent.size > 100) recent.remove(recent.first())
        }

        val reply = engine?.handle(room, sender, text) ?: return
        handler.postDelayed({ sendReply(n, reply) }, 700)
    }

    private fun sendReply(n: Notification, message: String) {
        val actions = (n.actions?.toList().orEmpty()) + Notification.WearableExtender(n).actions
        val action = actions.firstOrNull { !it.remoteInputs.isNullOrEmpty() }
        if (action == null) { Log.w(TAG, "답장 가능한 액션 없음"); return }
        try {
            val inputs = action.remoteInputs
            val bundle = Bundle()
            for (ri in inputs) bundle.putCharSequence(ri.resultKey, message)
            val intent = Intent()
            RemoteInput.addResultsToIntent(inputs, intent, bundle)
            action.actionIntent.send(this, 0, intent)
        } catch (e: Exception) {
            Log.e(TAG, "답장 실패", e)
        }
    }
}
