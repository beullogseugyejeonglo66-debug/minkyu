package com.minkyu.autoreply

import android.app.AppOpsManager
import android.app.KeyguardManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.PowerManager
import android.os.Process

class ForegroundAppDetector(private val ctx: Context) {

    companion object {
        fun hasUsageAccess(ctx: Context): Boolean {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            @Suppress("DEPRECATION")
            val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            return mode == AppOpsManager.MODE_ALLOWED
        }
        private val IGNORED = setOf("com.android.systemui", "com.sec.android.app.launcher", "com.samsung.android.app.aodservice")
    }

    fun current(): Presence {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!pm.isInteractive || km.isKeyguardLocked) return Presence.Idle
        if (!hasUsageAccess(ctx)) return Presence.Hidden   // 확인 불가 = 비공개 취급(안전 측)

        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usm.queryEvents(end - 24L * 3600_000, end)
        val ev = UsageEvents.Event()
        var cur: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            @Suppress("DEPRECATION")
            when (ev.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> cur = ev.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (cur == ev.packageName) cur = null
            }
        }
        val pkg = cur ?: return Presence.Idle
        if (pkg == ctx.packageName || pkg in IGNORED || pkg == homePackage()) return Presence.Idle
        if (!Prefs(ctx).isPublic(pkg)) return Presence.Hidden
        return Presence.App(labelOf(pkg))
    }

    private fun homePackage(): String? {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return ctx.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
    }

    private fun labelOf(pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }
}
