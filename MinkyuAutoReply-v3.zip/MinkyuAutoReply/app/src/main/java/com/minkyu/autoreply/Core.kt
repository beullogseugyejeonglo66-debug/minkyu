package com.minkyu.autoreply

import android.content.Context

/** 알림 경로와 화면 읽기 경로가 같은 대화 엔진을 공유한다. */
object Core {
    private var engine: ConversationEngine? = null
    private val recent = LinkedHashMap<String, Long>()
    private val sent = HashMap<String, Long>()

    /** 내가(앱이) 직접 보낸 문장 — 화면에서 다시 읽혀도 자동응답 대상에서 제외(무한반복 방지). */
    @Synchronized
    fun markSent(text: String) { sent[text.trim()] = System.currentTimeMillis() }

    @Synchronized
    fun handle(ctx: Context, room: String, sender: String, text: String): String? {
        val app = ctx.applicationContext
        val now = System.currentTimeMillis()
        sent.entries.removeAll { now - it.value > 10 * 60_000 }
        if (sent.containsKey(text.trim())) return null
        if (engine == null) {
            val prefs = Prefs(app)
            engine = ConversationEngine(
                keywords = { prefs.keywords() },
                presence = { ForegroundAppDetector(app).current() },
                notifyUser = { s, _ -> Notifier.post(app, Notifier.callAlert(s)) },
            )
        }
        recent.entries.removeAll { now - it.value > 3000 }
        val k = "$sender|$text"
        if (recent.containsKey(k)) return null   // 두 경로가 같은 메시지를 동시에 본 경우 1번만 처리
        recent[k] = now
        return engine!!.handle(room, sender, text)
    }
}
