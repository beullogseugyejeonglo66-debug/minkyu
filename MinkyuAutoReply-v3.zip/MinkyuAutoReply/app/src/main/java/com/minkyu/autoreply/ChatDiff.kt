package com.minkyu.autoreply

object ChatDiff {
    /** 이전 화면(prev) 끝부분과 현재 화면(cur) 앞부분이 겹치는 만큼을 빼고 나머지를 '새 메시지'로 본다. */
    fun <T> newTail(prev: List<T>, cur: List<T>): List<T> {
        if (prev.isEmpty() || cur.isEmpty()) return emptyList()
        for (m in minOf(prev.size, cur.size) downTo 1) {
            if (prev.takeLast(m) == cur.take(m)) return cur.drop(m)
        }
        return emptyList()
    }
}
