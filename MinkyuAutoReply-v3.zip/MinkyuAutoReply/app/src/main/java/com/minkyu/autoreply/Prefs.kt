package com.minkyu.autoreply

import android.content.Context

/** 설정 저장소. 공개 앱은 "허용 목록(whitelist)"으로만 저장 → 목록에 없는 앱(새 앱 포함)은 전부 비공개. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("minkyu_autoreply", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", true)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    var keywordsRaw: String
        get() = sp.getString("keywords", "김민규,민규") ?: "김민규,민규"
        set(v) = sp.edit().putString("keywords", v).apply()

    fun keywords(): List<String> =
        keywordsRaw.split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }

    fun publicApps(): Set<String> = HashSet(sp.getStringSet("public_apps", emptySet()) ?: emptySet())

    fun isPublic(pkg: String) = publicApps().contains(pkg)

    fun setPublic(pkg: String, pub: Boolean) {
        val s = publicApps().toMutableSet()
        if (pub) s.add(pkg) else s.remove(pkg)
        sp.edit().putStringSet("public_apps", s).apply()
    }
}
