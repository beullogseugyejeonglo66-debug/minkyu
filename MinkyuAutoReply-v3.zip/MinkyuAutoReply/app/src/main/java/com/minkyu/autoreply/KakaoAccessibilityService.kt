package com.minkyu.autoreply

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 카카오톡 채팅방이 화면에 열려 있을 때(=알림이 안 오는 상황) 화면의 메시지를 읽고
 * 입력창에 답장을 넣어 전송 버튼을 누른다. 카카오톡 패키지만 대상.
 * 뷰 ID에 의존하지 않고 화면 구조(스크롤 목록, 입력창, 텍스트 위치)로 추정한다 → 카톡 버전에 따라 오작동 가능.
 */
class KakaoAccessibilityService : AccessibilityService() {

    companion object {
        private const val KAKAO = "com.kakao.talk"
        private const val TAG = "MinkyuA11y"
        private val TIME = Regex("^(오전|오후)\\s?\\d{1,2}:\\d{2}$")
        private val COUNT = Regex("^\\d{1,3}$")
        private val SYSTEM = Regex("\\d{4}년 \\d{1,2}월 \\d{1,2}일|님이 (들어|나가|입장|퇴장|초대)|님을 초대|삭제된 메시지|읽지 않은 메시지")
    }

    data class Msg(val sender: String, val text: String)
    private class Piece(val text: String, val rect: Rect)

    private val handler = Handler(Looper.getMainLooper())
    private var lastScroll = 0L
    private var prevRoom = ""
    private var prev: List<Msg> = emptyList()
    private val lastSenderByRoom = HashMap<String, String>()
    private val scan = Runnable {
        try { scanChat() } catch (e: Exception) { Log.e(TAG, "scan 실패", e) }
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.packageName?.toString() != KAKAO) return
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) { checkCommand(e); return }
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) lastScroll = System.currentTimeMillis()
        handler.removeCallbacks(scan)
        handler.postDelayed(scan, 600)
    }

    private fun walk(n: AccessibilityNodeInfo, f: (AccessibilityNodeInfo) -> Unit) {
        f(n)
        for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, f) }
    }

    private fun findInput(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        walk(root) {
            if (found == null && it.isEditable && it.className?.toString()?.contains("EditText") == true) found = it
        }
        return found
    }

    private fun findList(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        walk(root) {
            val cn = it.className?.toString().orEmpty()
            if (it.isScrollable && (cn.contains("RecyclerView") || cn.contains("ListView") || cn.contains("ScrollView"))) {
                val r = Rect(); it.getBoundsInScreen(r)
                val area = r.width() * r.height()
                if (area > bestArea) { best = it; bestArea = area }
            }
        }
        return best
    }

    private fun findTitle(root: AccessibilityNodeInfo, h: Int): String? {
        var best: String? = null
        walk(root) {
            val t = it.text?.toString()?.trim()
            if (!t.isNullOrEmpty() && !it.isEditable) {
                val r = Rect(); it.getBoundsInScreen(r)
                if (r.top in 0 until (h * 0.14).toInt() && !COUNT.matches(t) && (best == null || t.length > best!!.length)) best = t
            }
        }
        return best
    }

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<Piece>) {
        val t = n.text?.toString()?.trim()
        if (!t.isNullOrEmpty() && !n.isEditable) {
            val r = Rect(); n.getBoundsInScreen(r)
            out.add(Piece(t, r))
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { collect(it, out) }
    }

    private fun parse(list: AccessibilityNodeInfo, w: Int, room: String): List<Msg> {
        val rows = ArrayList<Pair<Int, List<Piece>>>()
        for (i in 0 until list.childCount) {
            val row = list.getChild(i) ?: continue
            val ps = ArrayList<Piece>(); collect(row, ps)
            val r = Rect(); row.getBoundsInScreen(r)
            rows.add(r.top to ps)
        }
        rows.sortBy { it.first }
        var lastSender = lastSenderByRoom[room] ?: room
        val out = ArrayList<Msg>()
        for ((_, raw) in rows) {
            val ps = raw.filter { !TIME.matches(it.text) && !COUNT.matches(it.text) }
            if (ps.isEmpty() || ps.any { SYSTEM.containsMatchIn(it.text) }) continue
            val msg = ps.last()
            if (ps.size >= 2) {                       // 보낸 사람 이름 + 메시지 (남이 보낸 것)
                lastSender = ps.first().text
                out.add(Msg(lastSender, msg.text))
            } else {
                if (msg.rect.right >= w * 0.92) continue   // 오른쪽 정렬 = 내 메시지(봇 답장 포함) → 무시
                out.add(Msg(lastSender, msg.text))
            }
        }
        lastSenderByRoom[room] = lastSender
        return out
    }

    private fun scanChat() {
        if (!Prefs(this).enabled) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != KAKAO) return
        if (findInput(root) == null) { prev = emptyList(); prevRoom = ""; return }   // 채팅방 화면이 아님
        val dm = resources.displayMetrics
        val room = findTitle(root, dm.heightPixels) ?: "카카오톡"
        val list = findList(root) ?: return
        val msgs = parse(list, dm.widthPixels, room)

        val scrolling = System.currentTimeMillis() - lastScroll < 1500
        val fresh = if (room != prevRoom || scrolling) emptyList() else ChatDiff.newTail(prev, msgs)
        prevRoom = room
        prev = msgs

        var delay = 0L
        for (m in fresh) {
            val reply = Core.handle(this, room, m.sender, m.text) ?: continue
            handler.postDelayed({ sendTyped(reply) }, delay)
            delay += 1800
        }
    }

    /** @return 0=성공, 1=입력창에 쓰던 글이 있어 생략, 2=카톡 화면이 아님 */
    private fun sendTyped(text: String): Int {
        val root = rootInActiveWindow ?: return 2
        if (root.packageName?.toString() != KAKAO) return 2
        val input = findInput(root) ?: return 2
        val draft = if (input.isShowingHintText) "" else input.text?.toString().orEmpty()
        if (draft.isNotEmpty()) { Log.w(TAG, "입력창에 작성 중인 글이 있어 생략"); return 1 }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        handler.postDelayed({ clickSend() }, 500)
        return 0
    }

    // ───────── /cmds : 반복 전송 UI ─────────
    private var overlay: View? = null
    private var repeatToken = 0

    private fun toast(s: String) = Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show()

    private fun checkCommand(e: AccessibilityEvent) {
        val t = e.text?.joinToString("")?.trim().orEmpty()
        if (t != "/cmds" && t != "/stop") return
        e.source?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
        })
        if (t == "/cmds") showOverlay() else { repeatToken++; toast("반복을 중지했습니다") }
    }

    private fun closeOverlay() {
        val v = overlay ?: return
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) {}
        overlay = null
    }

    private fun showOverlay() {
        if (overlay != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
        fun field(hintText: String, number: Boolean = false) = EditText(this).apply {
            hint = hintText
            setHintTextColor(0xFF9A9A9A.toInt()); setTextColor(Color.WHITE)
            background = bg(0xFF303030.toInt(), 18)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            if (number) inputType = InputType.TYPE_CLASS_NUMBER
        }
        fun button(label: String, fill: Int, textColor: Int) = Button(this).apply {
            text = label; isAllCaps = false; setTextColor(textColor); background = bg(fill, 20)
        }
        fun full(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(top) }
        fun part(w: Float, start: Int) = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w)
            .apply { marginStart = dp(start) }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = bg(0xF2202020.toInt(), 28)
        }
        card.addView(TextView(this).apply { text = "/cmds"; setTextColor(Color.WHITE); textSize = 22f })

        val msg = field("보낼 내용을 적으세요").apply { minLines = 3; gravity = Gravity.TOP }
        card.addView(msg, full(12))
        val mention = field("멘션할 이름 (비우면 멘션 없음)")
        card.addView(mention, full(10))

        var repeatOn = false
        val toggle = button("반복 꺼짐", 0xFF303030.toInt(), Color.WHITE)
        val count = field("횟수", true)
        val gap = field("간격(초)", true)
        toggle.setOnClickListener {
            repeatOn = !repeatOn
            toggle.text = if (repeatOn) "반복 켜짐" else "반복 꺼짐"
            toggle.background = bg(if (repeatOn) 0xFFEBEBEB.toInt() else 0xFF303030.toInt(), 20)
            toggle.setTextColor(if (repeatOn) Color.BLACK else Color.WHITE)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(toggle, part(1.3f, 0)); row.addView(count, part(1f, 8)); row.addView(gap, part(1f, 8))
        card.addView(row, full(10))

        val close = button("닫기", 0xFF303030.toInt(), Color.WHITE)
        val send = button("전송", 0xFFEBEBEB.toInt(), Color.BLACK)
        close.setOnClickListener { closeOverlay() }
        send.setOnClickListener {
            val body = msg.text.toString().trim()
            if (body.isEmpty()) { toast("보낼 내용을 적어 주세요"); return@setOnClickListener }
            val name = mention.text.toString().trim().removePrefix("@")
            val text = if (name.isEmpty()) body else "@$name $body"
            val n = if (repeatOn) (count.text.toString().toIntOrNull() ?: 1).coerceIn(1, 50) else 1
            val sec = (gap.text.toString().toIntOrNull() ?: 5).coerceAtLeast(3)
            closeOverlay()
            startRepeat(text, n, sec)
        }
        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnRow.addView(close, part(1f, 0)); btnRow.addView(send, part(1f, 8))
        card.addView(btnRow, full(12))

        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(90)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        try { wm.addView(card, lp); overlay = card } catch (e: Exception) { Log.e(TAG, "오버레이 실패", e); toast("창을 띄우지 못했습니다") }
    }

    /** 안전장치: 최대 50회, 최소 간격 3초. 입력창에 /stop 을 치면 즉시 중지. */
    private fun startRepeat(text: String, count: Int, sec: Int) {
        val token = ++repeatToken
        var done = 0
        var attempts = 0
        val step = object : Runnable {
            override fun run() {
                if (token != repeatToken) return
                attempts++
                Core.markSent(text)
                val r = sendTyped(text)
                if (r == 2) { toast("카톡 화면이 아니어서 반복을 멈췄습니다"); return }
                if (r == 0) done++
                if (done >= count) { toast("전송 완료 (${done}회)"); return }
                if (attempts >= count * 3) { toast("전송이 계속 막혀 중지했습니다 (${done}회 전송)"); return }
                handler.postDelayed(this, sec * 1000L)
            }
        }
        toast(if (count > 1) "${count}회 반복 시작 · 중지: 입력창에 /stop" else "전송합니다")
        handler.postDelayed(step, 800)
    }

    private fun clickSend() {
        val root = rootInActiveWindow ?: return
        var target: AccessibilityNodeInfo? = null
        walk(root) {
            if (target == null) {
                val d = it.contentDescription?.toString()
                val t = it.text?.toString()
                val id = it.viewIdResourceName.orEmpty()
                if (d == "전송" || t == "전송" || id.endsWith("send")) target = it
            }
        }
        var n = target
        while (n != null && !n.isClickable) n = n.parent
        if (n == null) Log.w(TAG, "전송 버튼을 찾지 못함") else n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }
}
