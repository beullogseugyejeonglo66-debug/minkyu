package com.minkyu.autoreply

/** 사용자의 현재 상태. Hidden은 "비공개 앱 사용 중"과 "확인 불가"를 구분하지 않는다(유출 방지). */
sealed class Presence {
    object Idle : Presence()
    object Hidden : Presence()
    data class App(val label: String) : Presence()
}

/**
 * 안드로이드 의존성 없는 순수 로직. 대화 상태는 (방 + 발신자) 단위로 유지하므로
 * 단체방에서 다른 사람이 보낸 네/아니요에는 반응하지 않는다.
 */
class ConversationEngine(
    private val keywords: () -> List<String>,
    private val presence: () -> Presence,
    private val notifyUser: (sender: String, room: String) -> Unit,
    private val now: () -> Long = { System.currentTimeMillis() },
) {
    private enum class Stage { ASK_CALLED, ASK_NOTIFY }
    private class State(var stage: Stage, var at: Long)

    private val states = HashMap<String, State>()

    companion object {
        const val TIMEOUT_MS = 5 * 60 * 1000L
        const val Q_CALLED = "어플 | 지금 사용자를 부르신 건가요? 네, 아니요 중에 대답해 주세요."
        const val A_NOT_CALLED = "알겠습니다."
        const val Q_IDLE = "사용자는 지금 아무것도 안 하고 있습니다. 사용자에게 알려 드릴까요? 네, 아니요 둘 중 하나로 대답해 주세요."
        const val Q_HIDDEN = "사용자의 현재 활동은 비공개입니다. 사용자에게 알려 드릴까요? 네, 아니요 둘 중 하나로 대답해 주세요."
        const val A_DECLINE = "네, 알겠습니다."
        /** 명세에 없는 확인 문구(원치 않으면 빈 문자열로). */
        const val A_NOTIFIED = "사용자에게 알려 드렸습니다."
        fun qApp(label: String) =
            "사용자는 지금 현재 $label 앱을 하는 중입니다. 사용자 알림은 무음입니다. 사용자에게 알려 드릴까요? 네, 아니요 둘 중 하나로 대답해 주세요."

        private val YES = setOf("네", "넵", "넹", "예", "옙", "응", "어", "네네", "ㅇㅇ")
        private val NO = setOf("아니요", "아니오", "아뇨", "아니", "아냐", "ㄴㄴ", "아니에요", "아니여")
        private val ALL_MENTION = Regex("@\\s?(all|everyone|here|전체|모두)", RegexOption.IGNORE_CASE)
        private val NOISE = Regex("[\\s.!?~,。…^]+")
        private fun norm(t: String) = t.replace(NOISE, "").lowercase()
    }

    fun isCall(text: String): Boolean {
        val stripped = ALL_MENTION.replace(text, " ")   // @all/@전체 는 제거 후 판정
        return keywords().any { it.isNotBlank() && stripped.contains(it) }
    }

    /** @return 보낼 답장 (없으면 null = 무시) */
    @Synchronized
    fun handle(room: String, sender: String, text: String): String? {
        val key = "$room|$sender"
        states[key]?.let { if (now() - it.at > TIMEOUT_MS) states.remove(key) }

        if (isCall(text)) {
            states[key] = State(Stage.ASK_CALLED, now())
            return Q_CALLED
        }
        val st = states[key] ?: return null
        val n = norm(text)
        val yes = n in YES
        val no = n in NO
        if (!yes && !no) return null

        return when (st.stage) {
            Stage.ASK_CALLED -> if (no) {
                states.remove(key); A_NOT_CALLED
            } else {
                st.stage = Stage.ASK_NOTIFY; st.at = now()
                when (val p = presence()) {
                    is Presence.App -> qApp(p.label)
                    Presence.Idle -> Q_IDLE
                    Presence.Hidden -> Q_HIDDEN
                }
            }
            Stage.ASK_NOTIFY -> {
                states.remove(key)
                if (yes) { notifyUser(sender, room); A_NOTIFIED.ifEmpty { null } } else A_DECLINE
            }
        }
    }
}
