package com.minkyu.autoreply

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private data class AppItem(val pkg: String, val label: String)

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private val apps = ArrayList<AppItem>()
    private lateinit var adapter: AppAdapter

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val list = ListView(this)
        list.addHeaderView(buildHeader(), null, false)
        adapter = AppAdapter()
        list.adapter = adapter
        setContentView(list)

        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val items = pm.queryIntentActivities(intent, 0)
                .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .filter { it.pkg != packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
            runOnUiThread { apps.clear(); apps.addAll(items); adapter.notifyDataSetChanged() }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }

    private fun buildHeader(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        root.addView(TextView(this).apply { text = "민규 자동응답"; textSize = 22f })
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)

        root.addView(Switch(this).apply {
            text = "자동응답 사용"
            isChecked = prefs.enabled
            setOnCheckedChangeListener { _, c -> prefs.enabled = c }
        })
        root.addView(btn("1. 알림 접근 허용 (필수)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(btn("2. 사용 기록 접근 허용 (앱 확인용)") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        root.addView(btn("5. 카톡 화면 읽기 허용 (접근성: 채팅방 열어둔 상태용)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("3. 알림 표시 권한 (Android 13+)") {
            if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        })
        root.addView(btn("4. 배터리 최적화 설정 열기 (제한 없음 권장)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(btn("테스트: 호출 알림 보내기") {
            Notifier.post(this, Notifier.callAlert("테스트"))
        })
        root.addView(btn("테스트: 지금 내 상태 확인") {
            // 3초 뒤 확인 → 그 사이 다른 앱으로 이동해 볼 수 있음
            Toast.makeText(this, "3초 뒤 상태를 확인합니다. 다른 앱으로 이동해 보세요.", Toast.LENGTH_SHORT).show()
            val app = applicationContext
            Thread {
                Thread.sleep(3000)
                val p = ForegroundAppDetector(app).current()
                val msg = when (p) {
                    is Presence.App -> "공개 앱: ${p.label}"
                    Presence.Idle -> "아무것도 안 하는 중(또는 화면 꺼짐/홈)"
                    Presence.Hidden -> "비공개(또는 확인 불가)"
                }
                runOnUiThread { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }
            }.start()
        })

        root.addView(TextView(this).apply { text = "\n반응할 이름 (쉼표로 구분, 멘션용 내 카톡 닉네임도 추가)"; })
        val kw = EditText(this).apply { setText(prefs.keywordsRaw); setSingleLine() }
        root.addView(kw)
        root.addView(btn("이름 저장") {
            prefs.keywordsRaw = kw.text.toString()
            Toast.makeText(this, "저장됨", Toast.LENGTH_SHORT).show()
        })
        root.addView(TextView(this).apply {
            text = "\n앱 공개 설정: ON = 공개, OFF = 비공개 (기본 OFF, 새로 설치한 앱도 OFF)"
        })
        return root
    }

    private fun refreshStatus() {
        val listeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        val notif = listeners.contains(packageName)
        val usage = ForegroundAppDetector.hasUsageAccess(this)
        val a11y = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains(packageName)
        status.text = "알림 접근: ${if (notif) "허용됨 ✅" else "꺼짐 ❌ (필수)"}\n" +
            "사용 기록 접근: ${if (usage) "허용됨 ✅" else "꺼짐 ❌ (꺼져 있으면 항상 '비공개'로 답함)"}\n" +
            "카톡 화면 읽기(접근성): ${if (a11y) "허용됨 ✅" else "꺼짐 (채팅방을 열어둔 상태에선 반응 못 함)"}"
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(i: Int) = apps[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, cv: View?, parent: ViewGroup): View {
            val row = (cv as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(8), dp(16), dp(8))
                addView(TextView(context).apply {
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                addView(Switch(context))
            }
            val item = apps[i]
            (row.getChildAt(0) as TextView).text = item.label
            val sw = row.getChildAt(1) as Switch
            sw.setOnCheckedChangeListener(null)
            sw.isChecked = prefs.isPublic(item.pkg)
            sw.setOnCheckedChangeListener { _, c -> prefs.setPublic(item.pkg, c) }
            return row
        }
    }
}
