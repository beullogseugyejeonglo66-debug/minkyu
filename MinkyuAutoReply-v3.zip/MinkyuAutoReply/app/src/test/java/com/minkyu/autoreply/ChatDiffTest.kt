package com.minkyu.autoreply

import org.junit.Assert.assertEquals
import org.junit.Test

class ChatDiffTest {
    @Test fun noChange() = assertEquals(emptyList<String>(), ChatDiff.newTail(listOf("a", "b"), listOf("a", "b")))
    @Test fun appended() = assertEquals(listOf("c"), ChatDiff.newTail(listOf("a", "b"), listOf("a", "b", "c")))
    @Test fun scrolledAndAppended() = assertEquals(listOf("d"), ChatDiff.newTail(listOf("a", "b", "c"), listOf("b", "c", "d")))
    @Test fun firstSnapshotIgnored() = assertEquals(emptyList<String>(), ChatDiff.newTail(emptyList(), listOf("a")))
    @Test fun unrelatedIgnored() = assertEquals(emptyList<String>(), ChatDiff.newTail(listOf("a"), listOf("x", "y")))
}
