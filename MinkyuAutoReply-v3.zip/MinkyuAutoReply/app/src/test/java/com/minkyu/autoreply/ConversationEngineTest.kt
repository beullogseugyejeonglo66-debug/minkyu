package com.minkyu.autoreply

import org.junit.Assert.*
import org.junit.Test

class ConversationEngineTest {
    private var pres: Presence = Presence.Idle
    private val alerts = mutableListOf<String>()
    private var t = 0L
    private val e = ConversationEngine({ listOf("김민규", "민규") }, { pres }, { s, _ -> alerts.add(s) }, { t })

    @Test fun unrelatedIgnored() { assertNull(e.handle("방", "A", "안녕")); assertNull(e.handle("방", "A", "네")) }

    @Test fun allMentionIgnored() {
        assertNull(e.handle("방", "A", "@all 공지입니다"))
        assertNull(e.handle("방", "A", "@전체 확인 부탁"))
    }

    @Test fun namedCall() { assertEquals(ConversationEngine.Q_CALLED, e.handle("방", "A", "민규야")) }

    @Test fun noPath() {
        e.handle("방", "A", "민규")
        assertEquals(ConversationEngine.A_NOT_CALLED, e.handle("방", "A", "아니요"))
        assertNull(e.handle("방", "A", "네"))
    }

    @Test fun otherPersonIgnored() {
        e.handle("방", "A", "민규")
        assertNull(e.handle("방", "B", "네"))
        assertNull(e.handle("방", "B", "아니요"))
    }

    @Test fun idleFlowNotifies() {
        e.handle("방", "A", "김민규 님")
        assertEquals(ConversationEngine.Q_IDLE, e.handle("방", "A", "네"))
        e.handle("방", "A", "네")
        assertEquals(listOf("A"), alerts)
    }

    @Test fun publicAppShowsName() {
        pres = Presence.App("유튜브")
        e.handle("방", "A", "민규"); val r = e.handle("방", "A", "네")!!
        assertTrue(r.contains("유튜브"))
    }

    @Test fun hiddenDoesNotLeak() {
        pres = Presence.Hidden
        e.handle("방", "A", "민규"); val r = e.handle("방", "A", "네")
        assertEquals(ConversationEngine.Q_HIDDEN, r)
    }

    @Test fun declineSecond() {
        e.handle("방", "A", "민규"); e.handle("방", "A", "네")
        assertEquals(ConversationEngine.A_DECLINE, e.handle("방", "A", "아니요"))
        assertTrue(alerts.isEmpty())
    }

    @Test fun timeout() {
        e.handle("방", "A", "민규"); t += ConversationEngine.TIMEOUT_MS + 1
        assertNull(e.handle("방", "A", "네"))
    }
}
